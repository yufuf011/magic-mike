const dialog = document.querySelector("#transactionDialog");
const form = document.querySelector("#transactionForm");
const rows = document.querySelector("#transactionRows");
const balanceValue = document.querySelector("#balanceValue");
let balance = 4820.50;

document.querySelector("#addTransactionBtn").addEventListener("click", () => dialog.showModal());
document.querySelector("#closeDialog").addEventListener("click", () => dialog.close());

function pounds(value) {
  return new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(value);
}

function escapeText(value) {
  return value.replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
}

form.addEventListener("submit", event => {
  event.preventDefault();
  const merchant = document.querySelector("#merchantInput").value.trim();
  const amount = Number(document.querySelector("#amountInput").value);
  const type = document.querySelector("#typeInput").value;

  if (!merchant || !Number.isFinite(amount) || amount <= 0) return;

  const isIncome = type === "income";
  balance += isIncome ? amount : -amount;
  balanceValue.textContent = pounds(balance);

  const today = new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  const row = document.createElement("tr");
  const safeMerchant = escapeText(merchant);
  row.innerHTML = `
    <td><span class="merchant-icon ${isIncome ? "work" : "grocery"}">${isIncome ? "↗" : "•"}</span><span class="merchant-name"></span></td>
    <td><span class="tag ${isIncome ? "income-tag" : ""}">${isIncome ? "Income" : "Expense"}</span></td>
    <td>${today}</td>
    <td class="amount ${isIncome ? "positive" : "negative"}">${isIncome ? "+" : "−"}${pounds(amount)}</td>`;
  row.querySelector(".merchant-name").textContent = merchant;
  rows.prepend(row);
  form.reset();
  dialog.close();
});

document.querySelector("#periodSelect").addEventListener("change", event => {
  const period = event.target.value;
  const data = {
    week: {
      income: "M35 150 L120 95 L205 130 L290 75 L375 115 L460 62 L545 85 L630 42",
      expense: "M35 185 L120 160 L205 175 L290 145 L375 165 L460 135 L545 152 L630 125"
    },
    month: {
      income: "M35 145 L120 105 L205 125 L290 65 L375 92 L460 45 L545 70 L630 35",
      expense: "M35 185 L120 165 L205 175 L290 140 L375 160 L460 125 L545 145 L630 115"
    },
    year: {
      income: "M35 175 L120 145 L205 115 L290 130 L375 80 L460 92 L545 48 L630 30",
      expense: "M35 195 L120 180 L205 160 L290 170 L375 140 L460 150 L545 125 L630 105"
    }
  };
  const selected = data[period];
  document.querySelector("#incomeLine").setAttribute("d", selected.income);
  document.querySelector("#expenseLine").setAttribute("d", selected.expense);
  document.querySelector("#incomeArea").setAttribute("d", `${selected.income} L630 210 L35 210 Z`);
  document.querySelector("#expenseArea").setAttribute("d", `${selected.expense} L630 210 L35 210 Z`);
});

document.querySelector("#viewAllBtn").addEventListener("click", () => {
  rows.querySelectorAll("tr").forEach(row => row.classList.toggle("highlight-row"));
});
