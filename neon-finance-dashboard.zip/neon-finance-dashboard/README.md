# NEXUS — Finance Dashboard

A responsive, futuristic personal finance dashboard built with plain HTML, CSS and JavaScript.

## Features

- Dark interface with cyan and purple glow effects
- Responsive layout for desktop and mobile
- Balance, income and spending summary cards
- SVG cash-flow chart with week/month/year selector
- Monthly budget breakdown
- Add a demo income or expense and update the displayed balance
- No frameworks, build tools, API keys, or bank connections required

## Run it locally

1. Download or clone this repository.
2. Open `index.html` in your browser.

## Publish with GitHub Pages

1. Push these files to a GitHub repository.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Choose branch **main** and folder **/(root)**, then click **Save**.
5. Wait a minute and refresh the Pages section for the published URL.

## Important demo note

All initial numbers and transactions are fictional sample data. Added transactions update the page during the current session only. This project does not connect to bank accounts, save financial information permanently, or provide financial advice.
